-- Toggle Markview render
vim.keymap.set('n', '<leader>tm', '<CMD>Markview toggleAll<CR>', { noremap = true, desc = '[T]oggle [M]arkview' })
