-- Auto closing <html> / <JSX> tags
return {
  'windwp/nvim-ts-autotag',
  config = true,
}
