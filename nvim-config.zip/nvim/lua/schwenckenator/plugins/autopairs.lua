return {
  'windwp/nvim-autopairs',
  event = 'InsertEnter',
  opts = {},
}
