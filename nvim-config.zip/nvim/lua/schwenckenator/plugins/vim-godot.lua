return {
  'habamax/vim-godot',
  event = 'VimEnter',
}
