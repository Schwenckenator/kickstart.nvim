return {
  'tris203/precognition.nvim',
  event = 'VeryLazy',
  config = {},
}
