-- Typescript settings
vim.opt.smarttab = true
vim.opt.smartindent = true
vim.opt.expandtab = true

vim.opt.tabstop = 2
vim.opt.shiftwidth = 2
